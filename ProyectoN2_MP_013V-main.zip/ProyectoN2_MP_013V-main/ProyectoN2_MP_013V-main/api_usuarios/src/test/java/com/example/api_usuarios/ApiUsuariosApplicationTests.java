package com.example.api_usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
