package com.example.api_inscripciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiInscripcionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
