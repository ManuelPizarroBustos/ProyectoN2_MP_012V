package com.example.api_cursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
